/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programamedico2;

import view.Principal;

/**
 *
 * @author Professor
 */
public class ProgramaMedico2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Principal prin = new Principal();  // TODO code application logic here
        prin.setVisible(true);
    }
    
}
